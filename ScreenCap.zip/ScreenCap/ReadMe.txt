ScreenCap: This Program captures the screen using the GDI Functionality.

The Application when started adds an icon to the taskbar notification area and hides its main window. To capture the screen either double click on the icon in the notificaion area or use the menu item "capture screen" from the context menu that appears when right clicked. 

Once the screen captured - it can be pasted to any graphic editor like paint brush or can be saved as bmp file directly to the disk from the file menu after restoring the application main window. To restore the application main window from the taskbar use "show window" menu item from the context menu.